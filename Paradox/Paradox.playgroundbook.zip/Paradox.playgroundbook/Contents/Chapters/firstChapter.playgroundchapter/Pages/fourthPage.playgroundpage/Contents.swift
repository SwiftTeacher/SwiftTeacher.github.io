//#-code-completion(module, hide, Swift)
//#-code-completion(identifier, hide, _setup())
//#-code-completion(identifier, hide, AbstractDrawable)
//#-code-completion(identifier, hide, _ColorLiteralType)
//#-hidden-code
_setup()


//  Create an image
let image1 = Image(name: "dim.png")
image1.size.width *= 2.5
image1.size.height *= 2.5
image1.center.y += 0
image1.center.x += 0



//#-end-hidden-code

/*:#localized(key: "FirstProseBlock") 
 */



/*:#localized(key: "SecondProseBlock")
 */
