
/// 1. FRAMEWORKS

import UIKit
import PlaygroundSupport
import CoreGraphics
import GameplayKit

/// 2. CIRCLE VIEW CLASS

class vistaCircular: UILabel {
    var color = UIColor()
    override func draw(_ rect: CGRect) {
        var path = UIBezierPath(ovalIn: rect)
        
        color.setFill()
        path.fill()
    }
}

/// 3. BUTTON VIEW CLASS

class botonEspecial: UIButton {
    var color = UIColor()
    override func draw(_ rect: CGRect) {
        var path = UIBezierPath(ovalIn: rect)
        
        color.setFill()
        path.fill()
    }
}

/// 4. THE APP RANDOMLY CHOOSE A CHARACTER FROM THIS STRING (You can change this. Use emojis if you want)

let letrasAElegir = /*#-editable-code*/"ABCDEFGHIJKLMNÑOPQRSTUWXYZ"/*#-end-editable-code*/

let arrayLetra = Array(letrasAElegir.characters)

class ViewController: UIViewController {

/// 5. OBJECTS OF THE INTERFACE
    
    let letra = vistaCircular(frame: CGRect(x: 120, y: 130, width: 200, height: 200))
    let letraDos = vistaCircular(frame: CGRect(x: 25, y: 25, width: 150, height: 150))
    let letraTres = vistaCircular(frame: CGRect(x: 0, y: 0, width: 150, height: 150))
    let label = UILabel(frame: CGRect(x: 2, y: 20, width: 150, height: 100))
    let boton = botonEspecial(frame: CGRect(x: 180, y: 420, width: 80, height: 80))

/// 6. CREATE YOUR OWN OBJECTS TO PLACE INTO YOUR INTERFACE

//#-editable-code
//#-end-editable-code
    
/// 7. CREATING A TIMER AND A RANDOM NUMBER
    
    var timer = Timer()
    var azar = GKRandomDistribution(lowestValue: 0, highestValue: arrayLetra.count - 1)
    var vueltas = 0
    var descuento = 20
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
/// 8. CHANGE THE PROPERTIES AND METHODS OF YOUR OWN OBJECTS
        
//#-editable-code
//#-end-editable-code
        
        view.backgroundColor = /*#-editable-code*/#colorLiteral(red: 0.721568644046783, green: 0.886274516582489, blue: 0.592156887054443, alpha: 1.0)/*#-end-editable-code*/
        
        letra.color = /*#-editable-code*/#colorLiteral(red: 0.239215686917305, green: 0.674509823322296, blue: 0.968627452850342, alpha: 1.0)/*#-end-editable-code*/
        letraDos.color = /*#-editable-code*/#colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)/*#-end-editable-code*/
        letraTres.color =/*#-editable-code*/ #colorLiteral(red: 0.364705890417099, green: 0.0666666701436043, blue: 0.968627452850342, alpha: 1.0)/*#-end-editable-code*/
        boton.color =/*#-editable-code*/ #colorLiteral(red: 0.968627452850342, green: 0.780392169952393, blue: 0.345098048448563, alpha: 1.0)/*#-end-editable-code*/
        
        
        boton.addTarget(nil, action: #selector(lanzar), for: .touchUpInside)
       
        
        label.text = "?"
        label.font = UIFont(name: /*#-editable-code*/"GillSans-UltraBold"/*#-end-editable-code*/, size: /*#-editable-code*/100/*#-end-editable-code*/)
       
        label.textAlignment = .center
        label.textColor = /*#-editable-code*/#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)/*#-end-editable-code*/
        
        
        
        letra.layer.shadowColor = UIColor.black.cgColor
        letra.layer.shadowOpacity = 1
        letra.layer.shadowRadius = 5
        letra.layer.shadowOffset = CGSize.zero
        
        boton.layer.shadowColor = UIColor.black.cgColor
        boton.layer.shadowOpacity = 1
        boton.layer.shadowRadius = 5
        boton.layer.shadowOffset = CGSize.zero
        

/// 9. ADD OBJECTS INTO THE INTERFACE WITH THE .addSubview() METHOD.
        
//#-editable-code
//#-end-editable-code
        
        letra.addSubview(letraDos)
        letraDos.addSubview(letraTres)
        view.addSubview(letra)
        view.addSubview(boton)
        letraDos.addSubview(label)
    }
    @objc func lanzar() {
        boton.isUserInteractionEnabled = false
        timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: (#selector(eligiendoLetra)), userInfo: nil, repeats: true)
        
    }
    
    
    @objc func eligiendoLetra(){
        
        
        
        if vueltas < 30 {
            var toca = azar.nextInt()
            vueltas += 1
            label.text = "\(arrayLetra[toca])"
            
/// 10. ADD EVENTS THAT WILL TAKE PLACE WHILE THE LETTERS ARE CHANGING. FOR EXAMPLE, CHANGE THE BACKGROUND COLOR OF THE DIFFERENT OBJECTS.
            
//#-editable-code
//#-end-editable-code
        } else{
            
            timer.invalidate()
            vueltas = 0
            boton.isUserInteractionEnabled = true

/// 11. ADD EVENTS THAT WILL TAKE PLACE WHEN THE LETTERS STOP...
            
//#-editable-code
//#-end-editable-code
        }
        
    }
}



PlaygroundPage.current.liveView = ViewController()

