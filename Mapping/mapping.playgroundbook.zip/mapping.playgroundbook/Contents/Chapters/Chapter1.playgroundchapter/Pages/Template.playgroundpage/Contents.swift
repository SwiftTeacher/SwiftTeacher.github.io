//#-editable-code
import PlaygroundSupport
import UIKit

class ViewController: UIViewController{
    override func viewDidLoad() {
        //code here
    }
}

PlaygroundPage.current.liveView = ViewController()
//#-end-editable-code
