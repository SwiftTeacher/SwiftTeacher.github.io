//#-editable-code

import PlaygroundSupport
import SpriteKit

class GameScene: SKScene{
    
    override func didMove(to view: SKView) {
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}


let scene = GameScene(size: CGSize(width: 800, height: 1200))
scene.scaleMode = .aspectFill

let view = SKView(frame: CGRect(x:0, y:0, width: 800, height: 1200))
view.presentScene(scene)

PlaygroundPage.current.liveView = view
//#-end-editable-code
