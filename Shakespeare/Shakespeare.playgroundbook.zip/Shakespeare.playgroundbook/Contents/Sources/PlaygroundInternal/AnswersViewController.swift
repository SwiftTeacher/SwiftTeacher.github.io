//  AnswersViewController.swift

import UIKit
import PlaygroundSupport

class AnswersViewController: UIViewController, PlaygroundLiveViewMessageHandler {
    private var label: UILabel!
    private var image: UIImageView!
    
    var shakespeare = UIImage(named: "shakespeare_shades.png") {
        didSet {
            image.image = shakespeare
        }
    }
    private var message = "Press Play" {
        didSet {
            label.text = message
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.translatesAutoresizingMaskIntoConstraints = false

        label = UILabel()
        label.text = message
        label.textColor = .black
        label.font = UIFont.systemFont(ofSize: 16)
        label.lineBreakMode = .byWordWrapping
        label.numberOfLines = 0
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        
        image = UIImageView(image: shakespeare)
        image.translatesAutoresizingMaskIntoConstraints = false
        image.contentMode = .scaleAspectFit
        
        let stack = UIStackView(arrangedSubviews: [label, image])
        stack.axis = .vertical
        stack.alignment = .center
        stack.distribution = .fill
        stack.spacing = 20
        stack.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(stack)

        stack.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        stack.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        stack.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        stack.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        
        image.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.75).isActive = true
        image.heightAnchor.constraint(equalTo: image.widthAnchor).isActive = true
    }
    
    func receive(_ message: PlaygroundValue) {
        switch message {
        case .string(let value):
            self.message = value
        case .data(let pngData):
            self.shakespeare = UIImage(data: pngData)
        default:
            return
        }
    }
}


