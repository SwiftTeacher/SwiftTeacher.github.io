//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
//: # The Witch Detector App
/*:
 Make witch hunting easy with your own app!
 
 ### Part 1: Five Loaded Questions
 First develop five "loaded" questions to be asked of your classmates. Are there any behaviors habits that you view as undesirable? Use your own ulterior motives when you develop the questions.
 1. Use the show(string: String) function to pose a question. The entire question needs to be in quotation marks:
    ````
    show("What are your opinions about public displays of affection (PDA)?")
    ````
 2. Create an array (list) of possible answers to the question. Each possible answer needs to be contained in quotation marks and then separated with a comma.
    ````
    let question1Answers = askForChoice(options: ["I'm all for it!", "Disgusting!"])
    ````
 
 3. Award a point or points to the scoreboard based upon what you feel is the "right" answer.
    ````
    if question1Answers == "Disgusting!" {
        scoreboard += 1
     }
    ````

 4. Repeat this process for all remaining questions
 
 OPTIONAL: Add more possible answers to your arrays and then enable more than one correct answer or semi-correct answers using "else if" statements.
    ````
    if question1Answers == "Disgusting!" {
        scoreboard += 2
    } else if question1Answers == "Not sure" {
        scoreboard += 1
    }
    ````
*/
//#-editable-code Tap to enter code
// The scoreboard to track progress on questions
var scoreboard = 0

// Your first loaded question
show("<#String#>")
let question1Answers = askForChoice(options: ["<#String#>", "<#String#>"])
if question1Answers == "<#String#>" {
    scoreboard += <#T##Int#>
}

// Your second loaded question
show("<#String#>")
let question2Answers = askForChoice(options: ["<#String#>", "<#String#>"])
if question2Answers == "<#String#>" {
    scoreboard += <#T##Int#>
}

// Your third loaded question
show("<#String#>")
let question3Answers = askForChoice(options: ["<#String#>", "<#String#>"])
if question3Answers == "<#String#>" {
    scoreboard += <#T##Int#>
}

// Your fourth loaded question
show("<#String#>")
let question4Answers = askForChoice(options: ["<#String#>", "<#String#>"])
if question4Answers == "<#String#>" {
    scoreboard += <#T##Int#>
}

// Your fifth loaded question
show("<#String#>")
let question5Answers = askForChoice(options: ["<#String#>", "<#String#>"])
if question5Answers == "<#String#>" {
    scoreboard += <#T##Int#>
}
//#-end-editable-code

/*:
 ### Part 2: Determine Guilt or Innocence!
 5. Make a submit button
 6. If submit is pressed check the scoreboard in order to determine if the person guilty or not of witchcraft. Which scores will determine guilt and innocence?
 7. Make two messages: one for being guilty of witch craft and one for being not guilty
 8. Make two pictures: one representing a guilty verdict and the other representing and innocent verdict
 ````
 let submit = askForChoice(options: ["Submit"])
 if submit == "Submit" {
    if scoreboard >= 4 {
        show("Not a witch!")
        show(insert innocent picture with the + sign)
    } else if scoreboard <= 3 {
        show("Vile witch! Thou shall be punish'd")
        show(insert guilty picture with the + sign)
    }
 }
 ````
 */
 //#-editable-code Tap to enter code
// Submit button
let submit = askForChoice(options: ["<#String#>"])
if submit == "<#String#>" {
    // Innocent code
    if scoreboard >= <#T##Int#> {
        show("<#String#>")
        show(<#T##image: UIImage##UIImage#>)
    // Guilty code
    } else if scoreboard <= <#T##Int#> {
        show("<#String#>")
        show(<#T##image: UIImage##UIImage#>)
    }
}
 //#-end-editable-code
