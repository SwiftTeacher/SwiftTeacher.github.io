//
//  Assessments.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import Foundation
import PlaygroundSupport
import AVFoundation

public class AssessmentManager {
    
    static let page = PlaygroundPage.current
    
    static let checker = ContentsChecker(contents: page.text)
    
    public static func callAssessment() {
        if checker.contents.contains("01.playgroundpage") {
            AssessmentManager.page01assessmentPoint()
        } else if checker.contents.contains("02.playgroundpage") {
            AssessmentManager.page02assessmentPoint()
        } else if checker.contents.contains("03.playgroundpage") {
            AssessmentManager.page03assessmentPoint()
        } else if checker.contents.contains("04.playgroundpage") {
            AssessmentManager.page04assessmentPoint()
        } else if checker.contents.contains("05.playgroundpage") {
            AssessmentManager.page05assessmentPoint()
        } else if checker.contents.contains("06.playgroundpage") {
            AssessmentManager.page06assessmentPoint()
        } else {
            AssessmentManager.page07assessmentPoint()
        }
    }
    
    public static func page01assessmentPoint() {
        let successString = NSLocalizedString("### Whoa, nice work! \n\nNotice how the camera found [feature points](glossary://feature%20point) and connected them to detect [planes](glossary://plane) in the scene? Your device is trying to find all the objects in your environment so that when you place your models, it looks like they’re sitting on the surfaces of real things around you, like tables or the floor. \n\nOn the [next page](@next), you’ll learn how to start building your own scene by creating and adding a [model](glossary://model).", comment:"Success message for first page.")
        let firstHint = NSLocalizedString("Try changing `doSomethingWhimsical` to another [command](glossary://command), such as `doSomethingMysterious`, and running your code.", comment:"Hint for `doSomethingMysterious` function.")
        let secondHint = NSLocalizedString("Want to see all the code? Open the **SharedCode** file by tapping the [files button](glossary://files%20button) and select **SharedCode**.", comment:"Opening module hint.")
        let cameraPermissionHint = NSLocalizedString("To complete this page you need to give permission to use the camera on your iPad. Please close this playground by going back to ‘My Playgrounds’. Then open it again, run your code, and tap ‘OK’ when asked if you want to use the camera.", comment: "Hint for permissions.")
        
        var hints = [firstHint, secondHint]
        
        let status = AVCaptureDevice.authorizationStatus(for: .video)
        
        if status == .denied {
            hints.insert(cameraPermissionHint, at: 0)
            PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
        }
        
        if let playgroundValue = PlaygroundKeyValueStore.current["page01Assessment"] {
            return
        } else {
            if checker.functionCallCount(forName: "doSomethingMysterious") == 1 || checker.functionCallCount(forName: "doSomethingFriendly") == 1  {
                PlaygroundKeyValueStore.current["page01Assessment"] = PlaygroundValue.boolean(true)
                PlaygroundPage.current.assessmentStatus = .pass(message: successString)
            } else {
                PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
            }
        }
    }
    
    public static func page02assessmentPoint() {
        let successString = NSLocalizedString("### Great Augmentation! \n\n Now that you can add a [model](glossary://model), try changing it to something else, like `Model.cactus`, `Model.foot`, or `Model.lightbulb`. Add as many models as you want! \n\nUp [next](@next), you’ll find out how to scale, move, and rotate your model using Actions.", comment:"Success message for second page.")
        let firstHint = NSLocalizedString("First, you’ll need to create a [variable](glossary://variable) to store your model.\n\n - Example: `var model = Model.snail`", comment:"First hint for adding a model.")
        let secondHint = NSLocalizedString("Next, you’ll need to [call](glossary://call) `scene.add` and [pass](glossary://pass) in your variable, `model`.\n\n - Example: `scene.add(model)`", comment:"Second hint for adding a model.")
        let thirdHint = NSLocalizedString("Finally, add some code to run when the scene starts by putting it inside the braces of `setOnStartHandler`. This is a special syntax called a [closure](glossary://closure) that makes it possible for you to run a [function](glossary://function) right in place, without a name.\n\n```\nscene.setOnStartHandler {\n   model.animate()\n}\n```", comment: "Third hint for adding a model.")
        
        let hints = [firstHint, secondHint, thirdHint]
        
        if let playgroundValue = PlaygroundKeyValueStore.current["page02Assessment"] {
            return
        } else {
            if checker.functionCallCount(forName: "scene.add") >= 1 {
                PlaygroundKeyValueStore.current["page02Assessment"] = PlaygroundValue.boolean(true)
                PlaygroundPage.current.assessmentStatus = .pass(message: successString)
            } else {
                PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
            }
        }
    }
    
    public static func page03assessmentPoint() {
        let successString = NSLocalizedString("### Excellent! \n\nNotice that one Action — **moveBy** — takes values for **x**, **y**, and **z**. This is because AR uses a three-dimensional (3D) set of [axes](glossary://axis) to determine the location of models in space. Adjusting **x** moves objects left to right; **y** moves objects up and down; and, **z** moves objects forward and back.\n\n[Next](@next), you’ll learn about distance events.", comment:"Success message for third page.")
        let firstHint = NSLocalizedString("To create your [Action](glossary://Action): \n\n1. Add your [variable](glossary://variable), `rainCloud`. \n\n2. At the end of `rainCloud`, add a period (`.`) to indicate that you want to run a [function](glossary://function) from that variable. \n\n3. [Call](glossary://call) `run(action:)`, and enter the `.moveTo` Action, along with any values that you want to pass in.", comment:"First hint for adding an action")
        let secondHint = NSLocalizedString("Here’s an example of how you might create an [Action](glossary://Action) to move the rain cloud to the snail:\n\n - Example: `rainCloud.run(action: .moveTo(snail.location, duration: 5))`", comment:"Second hint for adding an action.")
        let thirdHint = NSLocalizedString("Here’s an example of how to run the `rotateBy` and `scaleTo` [Actions](glossary://Action).\n\n```\nsnail.run(action: .rotateBy(x: 0, y: 20, z: 0, duration: 1)\n\nsnail.run(action: .scaleTo(0.1, duration: 5)", comment: "Third hint for adding an action.")
        let fourthHint = NSLocalizedString("In addition to running one action, you can run *multiple* actions either sequentially (in a row) or simultaneously (all at the same time):\n\n```\nmodel.run(sequence: [.scaleBy(2, duration: 1), .rotateBy(x: 0, y: 10, z: 0, duration: 1)])\n\nmodel.run(group: [.scaleTo(2, duration: 1), .rotateBy(x: 0, y: 10, z: 0, duration: 1)])\n\n```\n\nInstead of passing in a single action, you pass in one or more actions (separated by commas) in an [array](glossary://array).", comment:"Fourth hint for adding an action.")
        
        let hints = [firstHint, secondHint, thirdHint, fourthHint]
        
        if let playgroundValue = PlaygroundKeyValueStore.current["page03Assessment"] {
            return
        } else {
            if checker.functionCallCount(forName: "rainCloud.run") >= 1 {
                PlaygroundKeyValueStore.current["page03Assessment"] = PlaygroundValue.boolean(true)
                PlaygroundPage.current.assessmentStatus = .pass(message: successString)
            } else {
                PlaygroundPage.current.assessmentStatus =  .fail(hints: hints, solution: nil)
            }
        }
    }
    
    public static func page04assessmentPoint() {
        let successString = NSLocalizedString("### Perfection!\n\nNow that you know how to create one [distance event](glossary://distance%20event), you can add as many as you want in a scene. This means that different models can respond in unqiue ways when you get close to them. Pretty cool!\n\nUp [next](@next), you’ll figure out how to enhance your AR experience with [completion handlers](glossary://completion%20handler).", comment:"Success message for fourth page.")
        let firstHint = NSLocalizedString("To write a [distance event](glossary://distance%20event): \n\n1. Use `scene.camera` to define the first model in your event. In this case, it’s the camera on your iPad. \n\n2. From `scene.camera`, [call](glossary://call) `when(_:isWithin:do)` and pass in the second model in your event, the moth, as the first [argument](glossary://argument). \n\n3. You’ll also need to pass in the distance at which your event triggers, such as `5.cm`. Notice the `.cm` at the end? You can choose the unit of distance, such as `m`(meters), `cm`(centimeters), or `mm`(millimeters).\n\n4. Finally, define what you want to happen when your event triggers.", comment:"First hint for creating a distance event.")
        let secondHint = NSLocalizedString("To define what happens when your event triggers, you can use a [closure](glossary://closure), which is a function that’s defined right in place. To do that, add a pair of braces that contain the code you want to execute as your [argument](glossary://argument) to the `do` parameter, like this:\n\n```\nscene.camera.when(moth, isWithin: 5.cm, do: {\n   // ✏️ Code to run.\n})\n```", comment:"Second hint for creating a distance event.")
        let thirdHint = NSLocalizedString("Since the [scene’s](glossary://scene) camera is attached to the iPad, you’re actually detecting how close the iPad comes to the [model](glossary://model) in the scene. Since your iPad moves with you, your movement determines when the event triggers!", comment:"Third hint for creating a distance event.")
        
        let hints = [firstHint, secondHint, thirdHint]
        
        if let playgroundValue = PlaygroundKeyValueStore.current["page04Assessment"] {
            return
        } else {
            if checker.functionCallCount(forName: "scene.camera.when") >= 1 {
                PlaygroundKeyValueStore.current["page04Assessment"] = PlaygroundValue.boolean(true)
                PlaygroundPage.current.assessmentStatus = .pass(message: successString)
            } else {
                PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
            }
        }
    }
    
    public static func page05assessmentPoint() {
        let successString = NSLocalizedString("### Your work is complete! \n\nUsing a [completion handler](glossary://completion%20handler) is really common in coding, because they give you the ability to verify that one block of code finishes before running another.\n\n[Next](@next), learn how to harness one of the most important parts of your AR scene: the camera.", comment: "Success text for page 05.")
        let firstHint = NSLocalizedString("[Call](glossary://call) `animate(_:repeats:completion:)` from your hand model.\n\n ```\nhand.animate(.point, repeats: .none, completion: {\n   // ✏️ Code to run. \n}) ", comment:"First hint for adding a completion handler.")
        let secondHint = NSLocalizedString("Inside your completion handler’s [closure](glossary://closure), make the lemon animate and your text `disappear`.\n\n```\nhand.animate(.point, repeats: .none, completion: {\n   lemon.animate(.juice)\n   text.disappear()\n})", comment:"Second hint for adding a completion handler.")
        let thirdHint = NSLocalizedString("Can you add a completion handler inside a completion handler? Of course you can!\n\n```\nlemon.play(.ring, loops: .none, completion: {\n   lemon.run(action: .scaleBy(2, duration: 1, completion: {\n      lemon.play(.buzz)\n   })\n})", comment:"Third hint for adding a completion handler.")
        
        
        let hints = [firstHint, secondHint, thirdHint]
        let completions = checker.contents.components(separatedBy: "completion:")
        let completionsCount = completions.count - 1
        
        if let playgroundValue = PlaygroundKeyValueStore.current["page05Assessment"] {
            return
        } else {
            if completionsCount >= 7 {
                PlaygroundKeyValueStore.current["page05Assessment"] = PlaygroundValue.boolean(true)
                PlaygroundPage.current.assessmentStatus = .pass(message: successString)
            } else {
                PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
            }
        }
    }
    
    public static func page06assessmentPoint() {
        let successString = NSLocalizedString("### Well done!\n\n You now have all the skills required to create an incredible AR experience. If you need a recap of any skills, go back and review before you move on:\n\n1. [Create models and add them to scene](01)\n\n2. [Trigger code when the scene starts](01)\n\n3. [Animate a model](02)\n\n4. [Run Actions on a model](03)\n\n5. [Create a distance event](04)\n\n6. [Create a completion handler](05)\n\n If you’re ready, [move on](@next) to creating your own scene!", comment: "Success text for page 06.")
        let firstHint = NSLocalizedString("To run code when the scene starts, place it inside `scene.setOnStartHandler`.\n\n```\nscene.setOnStartHandler {\n   // ✏️ Code to run when the scene starts.\n}", comment:"First hint for using the camera.")
        let secondHint = NSLocalizedString("To create a [distance event](glossary://distance%20event), use the syntax below. Notice how you’ll again use a [closure](glossary://closure) to define what happens when the event triggers.\n\n```\nscene.camera.when(snail, isWithin: 10.cm, do: {\n   // ✏️ Code to run when the distance event triggers.\n})\n```", comment:"Second hint for using the camera.")
        let thirdHint = NSLocalizedString("To make a model follow you or flee from you, pass in `scene.camera.node` as the [argument](glossary://argument) to `flee` or `follow`.\n\n```\nmoth.follow(scene.camera.node, at: 5.cm)\nsnail.flee(from: scene.camera.node, safeDistance: 25.cm)", comment:"Third hint for using the camera.")
        let solution = NSLocalizedString("```\nvar moth = Model.flyingBug\nvar snail = Model.snail\n\nscene.add([snail, moth])\n\nscene.setOnStartHandler {\n   moth.follow(scene.camera.node, at: 5.cm)\n}\n\nscene.camera.when(snail, isWithin: 10.cm, do: {\n   snail.flee(from: scene.camera.node, safeDistance: 20.cm)\n})", comment:"Solution for adding flee and follow.")
        
        let hints = [firstHint, secondHint, thirdHint]
        

        let flees = checker.contents.components(separatedBy: "flee(from:")
        let follows = checker.contents.components(separatedBy: "follow(")
        
        if let playgroundValue = PlaygroundKeyValueStore.current["page06Assessment"] {
            return
        } else {
            if checker.functionCallCount(forName: "scene.camera.when") >= 1 && (checker.functionCallCount(forName: "scene.setOnStartHandler") >= 1 || checker.usedVariables.contains("scene.setOnStartHandler")) && flees.count >= 4 && follows.count >= 4 {
                PlaygroundKeyValueStore.current["page06Assessment"] = PlaygroundValue.boolean(true)
                PlaygroundPage.current.assessmentStatus = .pass(message: successString)
                
            } else {
                PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: solution)
            }
        }
    }
    
    public static func page07assessmentPoint() {
        
        let ideasHint = NSLocalizedString("Here are a couple things you could do with your **AR toolkit**: \n\n 1. Leave a virtual note for someone in a hidden spot.\n 2. Create a scavenger hunt full of surprises. \n 3. Build a miniature drama unfolding on a tabletop. \n 4. Construct your own art exhibit.\n 5. Anything else you can dream of 🎆🛤🎑!", comment:"Ideas for using AR.")
        let firstHint = NSLocalizedString("**Adding a model:** \n\n```\nvar model = Model.Lemon\nscene.add(model)\n``` \n\n**Adding multiple models:** \n\n```\nvar ear = Model.Ear\nvar eye = Model.Eye\n\nscene.add([ear,eye])", comment:"First hint for adding a model.")
        let secondHint = NSLocalizedString("**Triggering code when the scene starts:** \n\n```\nscene.setOnStartHandler {\n   play(.spines)\n}", comment:"Second hint for adding a model.")
        let thirdHint = NSLocalizedString("**Animate a model:** \n\n```\nvar mouth = Model.Mouth\nvar eye = Model.Eye\n\nmouth.animate(.smile)\n``` \n\n**Animate a model with a completion handler:** \n\n```\neye.animate(.lookRight, repeats: .number(3), completion: {\n   eye.disappear()\n})", comment:"Third hint for adding a model.")
        let fourthHint = NSLocalizedString("**Run an Action on a model:** \n\n```\nvar nose = Model.Nose\n\nnose.run(action: .scaleTo(3, duration: 10))\n```\n\n**Run multiple actions** either sequentially (in a row) or simultaneously (all at the same time): \n\n```\nnose.run(sequence: [.scaleBy(2, duration: 1), .rotateBy(x: 0, y: 10, z: 0, duration: 1)])\n\nnose.run(group: [.scaleBy(2, duration: 1), .rotateBy(x: 0, y: 10, z: 0, duration: 1)])", comment:"Fourth hint for adding a model.")
        let fifthHint = NSLocalizedString("**Create a distance event:** \n\n```\nvar moth = Model.Moth\n\nscene.camera.when(moth, isWithin: 20.mm, do: {\n   moth.follow(scene.camera.node)\n})", comment:"Fifth hint for adding a model.")
        let sixthHint = NSLocalizedString("**Create a completion handler:** \n\n```\nplay(.buzz, rate: 2, loops: false, completion: {\n   play(.tear)\n})", comment:"Sixth hint for adding a model.")
        let seventhHint = NSLocalizedString("**Have a model follow or flee from the camera:** \n\n```\nvar snail = Model.Snail\n\nsnail.follow(scene.camera.node, at: 5.cm)\nsnail.flee(from: scene.camera.node, safeDistance: 20.cm)", comment:"Seventh hint for adding a model.")
        
        let hints = [ideasHint, firstHint, secondHint, thirdHint, fourthHint, fifthHint, sixthHint, seventhHint]
        
        PlaygroundPage.current.assessmentStatus = .fail(hints: hints, solution: nil)
    }
}
