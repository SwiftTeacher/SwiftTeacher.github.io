
import ARKit
import SceneKit
import PlaygroundSupport

// READ ME: This playground is very resource intense! If failure occurs, restart SPG App.

class ARViewController: UIViewController, ARSCNViewDelegate, ARSessionDelegate{
    
    // MARK: - Properties & Outlets
    var sceneView: ARSCNView! = nil
    let scene = SCNScene()
    
    // MARK: - View Management
    override func loadView(){
        initSceneView()
    }
    
    // MARK: Initialization
    func initSceneView(){
        sceneView = ARSCNView(frame: CGRect(x: 0.0, y: 0.0, width: 500.0, height: 600.0))
        
        sceneView.scene = scene
        
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = .horizontal
        
        //set up scene view
        sceneView.setup()
        
        //set view delegate
        let session = ARSession()
        sceneView.delegate = self
        sceneView.session = session
        sceneView.debugOptions = [ARSCNDebugOptions.showFeaturePoints, ARSCNDebugOptions.showWorldOrigin]
        sceneView.showsStatistics = true
        
        //get messages when plane detected
        sceneView.session.delegate = self
        
        //default light
        sceneView.autoenablesDefaultLighting = true
        
        self.view = sceneView
        sceneView.session.run(config, options: [.resetTracking, .removeExistingAnchors])
        
    }
    
}

// MARK: ARSCNView Settings
extension ARSCNView{
    func setup(){
        antialiasingMode = .multisampling2X
        automaticallyUpdatesLighting = false
        
        preferredFramesPerSecond = 60
        contentScaleFactor = 1.0
        
        if let camera = pointOfView?.camera {
            camera.wantsHDR = true
            camera.wantsExposureAdaptation = true
            camera.exposureOffset = -1
            camera.minimumExposure = -1
            camera.maximumExposure = 3
            
            // MARK: Adding Content
            let hello = SCNText(string: "Swift Teacher", extrusionDepth: 5)
            let helloNode = SCNNode(geometry: hello)
            helloNode.scale = SCNVector3(0.1, 0.1, 0.1)
            
            //cameraNode.addChildNode(helloNode)
            scene.rootNode.addChildNode(helloNode)
        }
    }
}

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = ARViewController()

