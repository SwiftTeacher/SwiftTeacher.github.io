//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
//#-editable-code Tap to enter code
//: # Random Shakespearean Insults

/*:
 ### Change the Picture
 Call the setPicture function if you would like to change the picture to one of your own.
 
 - Example:\
 \
 `setPicture(image: UIImage)`
 */

/*:
 ### Array Building
 Three empty arrays have been declared below: 2 for adjectives and 1 for nouns. Complete each array with insulting words found in a Shakespearean play. The words need to be placed inside the square brackets ([ ]) with each one enclosed in quotation marks (""). A comma (,) then separates each word and is placed outside of the quotation marks. The more words that you can place in each array, the better.
 
 - Example:\
 \
 `var adjectiveList1 = ["frothy", flea-bitten", "bawdy", "bumbling", "bootless", "dankish"]`
*/
var adjectivesList1 = []

var adjectivesList2 = []

var nounList = []

/*:
 ### Putting it all together
The .randomElement method is used to select a random word from each array. Using string interpolation, the three randomly selected words are added to "Thou". The "show" function displays a new insult every time the play button is pressed."
*/
show("Thou \(adjectivesList1.randomElement()) \(adjectivesList2.randomElement()) \(nounList.randomElement()).")

//#-end-editable-code
