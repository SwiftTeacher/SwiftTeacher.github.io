//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
//#-editable-code Tap to enter code
/*:
 # Randomized Found Poetry
 Use this page to create randomly generated found poetry based upon literary works, historical texts, or speeches.
 */

/*:
 ### Change the Picture
 Call the setPicture function to change the picture to match the theme of your found poem.
 
 - Example:\
 \
 `setPicture(image: UIImage)`
 */

/*:
 ### Array Building
 Complete the arrays below with multiple found passages or words from literary works, speeches, or historical texts, and add more arrays if necessary. Passages in each array can come from different works, but should have related themes. Each passage needs to be placed inside the square brackets ([ ]) with each one enclosed in quotation marks (""). A comma (,) then separates each passage from one another and is placed outside of the quotation marks.
 
 - Example:\
 \
 `var line1Array = ["We hold these truths to be self-evident, that all men are created equal.", "Four score and seven years ago our fathers brought forth on this continent, a new nation, conceived in liberty, and dedicated to the proposition that all men are created equal"]`
 */
var line1Array = []

var line2Array = []

var line3Array = []

/*:
 ### Putting it all together
 The .randomElement method is used to select a random passage from each array. Using string interpolation, the three randomly selected passages will be put together in a found poem every time the play button is pressed. If additional arrays were added, they also need to be placed in the string below using string interpolation.
 `\(arrayName.randomElement)`.
 */
show("\(line1Array.randomElement()) \(line2Array.randomElement()) \(line3Array.randomElement()).")

//#-end-editable-code

