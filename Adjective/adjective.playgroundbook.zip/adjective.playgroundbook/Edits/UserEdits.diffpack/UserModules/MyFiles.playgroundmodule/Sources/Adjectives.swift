

public func adjectiveHunt() {
    
    var label = Model.text("Beautiful", elevation: 1.cm)
    scene.add(label)
    label.applyColor(scheme: .cool)
    label.run(action: .scaleTo(1, duration: 1))
    
    
    
    
    
    
    
    
    
    
    
    
    
        
            
            
        

        
        
        
        
        
        
        
        
        

}
