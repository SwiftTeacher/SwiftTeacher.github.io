//  AnswersPlayground.swift

import UIKit
import Foundation

private let answersLiveViewClient = AnswersLiveViewClient()

extension Array {
    
    public func randomElement() -> Element {
        let i = Index(arc4random_uniform(UInt32(count)))
        return self[i]
    }
    
}

public func show(_ message: String) {
    answersLiveViewClient.show(message)
}

public func setPicture(_ image: UIImage) {
    answersLiveViewClient.changeImage(image)
}
