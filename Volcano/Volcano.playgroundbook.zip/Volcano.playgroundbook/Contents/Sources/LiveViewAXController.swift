//
//  LiveViewAXController.swift
//  SupportingContent
//
//  Copyright © 2018 Apple Inc. All rights reserved.
//

import UIKit

class LiveViewAXController : UIViewController {
    let masterStackView = UIStackView(arrangedSubviews: [])
    let axStackView = UIStackView(arrangedSubviews:[])
    
    /*var masterViewController: UIViewController? {
        get {
            
        }
        set (value) {
            
            
            if !masterStackView.subviews.contains(axStackView) {
                //masterStackView.
            }
        }
    }
    
    func addAXViewController(_ axVC: UIViewController) {
        
    }
    
    func removeAXViewController( _ axVC: UIViewController) {
    
    }*/
}
