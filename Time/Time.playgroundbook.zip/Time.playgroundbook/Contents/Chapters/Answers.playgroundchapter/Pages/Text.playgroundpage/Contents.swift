//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
//: # Time Telling Quiz
/*:
 Quiz your classmates on their knowledge of telling time in Spanish.
 
 1. To start, make at least 5 pictures showing 5 different times.
 2. Use the show(image: UIImage) function to display each time picture.
    ````
    show(insert picture with the + sign)
    ````
 2. Use the askForChoice function to make a list of at least 4 possible answers (times in Spanish).
    ````
    let question1Answers = askForChoice(options: ["Son las ocho y veinticinco", "Son las doce menos diez", "Es la una menos veinticinco", "Son las cinco y cuarto"])
    ````
 
 3. Determine if the correct time was selected and show either a correct or incorrect message. Add a point to the scoreboard if the answer is correct.
    ````
    if question1Answers == "doce treinta y seis de la mañana" {
        show("Correcto!")
        scoreboard += 1
    } else {
        show("Incorrecto!")
    }
    ````
 4. Repeat this process for all remaining questions
 
 5. Calculate the score: Determine the minimum score out of 5 that consitutes a positve score and then show a message and a picture that communicates a job well done. Next show a message and a picture to communicate that more improvement is needed.
*/
//#-editable-code Tap to enter code
// scoreboard variable to keep track of quiz score
var scoreboard = 0

// Question 1
show(<#T##image: UIImage##UIImage#>)
let question1Answers = askForChoice(options: ["<#String#>", "<#String#>", "<#String#>", "<#String#>"])
if question1Answers == "<#String#>" {
    show("<#String#>")
    scoreboard += <#T##Int#>
} else {
    show("<#String#>")
}

// Question 2
show(<#T##image: UIImage##UIImage#>)
let question2Answers = askForChoice(options: ["<#String#>", "<#String#>", "<#String#>", "<#String#>"])
if question2Answers == "<#String#>" {
    show("<#String#>")
    scoreboard += <#T##Int#>
} else {
    show("<#String#>")
}

// Question 3
show(<#T##image: UIImage##UIImage#>)
let question3Answers = askForChoice(options: ["<#String#>", "<#String#>", "<#String#>", "<#String#>"])
if question3Answers == "<#String#>" {
    show("<#String#>")
    scoreboard += <#T##Int#>
} else {
    show("<#String#>")
}

// Question 4
show(<#T##image: UIImage##UIImage#>)
let question4Answers = askForChoice(options: ["<#String#>", "<#String#>", "<#String#>", "<#String#>"])
if question4Answers == "<#String#>" {
    show("<#String#>")
    scoreboard += <#T##Int#>
} else {
    show("<#String#>")
}

// Question 5
show(<#T##image: UIImage##UIImage#>)
let question5Answers = askForChoice(options: ["<#String#>", "<#String#>", "<#String#>", "<#String#>"])
if question5Answers == "<#String#>" {
    show("<#String#>")
    scoreboard += <#T##Int#>
} else {
    show("<#String#>")
}

// Calculates the score
let calculateScore = askForChoice(options: ["Calculate Score"])
if calculateScore == "Calculate Score" {
    show("You scored \(scoreboard) out of 5 correct")
    // Positive score
    if scoreboard >= <#T##Int#> {
        show("<#String#>")
        show(<#T##image: UIImage##UIImage#>)
    // Needs improvement
    } else {
        show("<#String#>")
        show(<#T##image: UIImage##UIImage#>)
    }
}
//#-end-editable-code

