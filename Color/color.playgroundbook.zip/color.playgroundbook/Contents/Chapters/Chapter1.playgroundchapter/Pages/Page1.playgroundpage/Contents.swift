//#-editable-code

import PlaygroundSupport
import SpriteKit

class GameScene: SKScene, SKPhysicsContactDelegate {
    
    struct PhysicsCategory{
        static let Player: UInt32 = 1
        static let Obstacles: UInt32 = 2
    }
    
    let player = SKShapeNode(circleOfRadius: 20)
    let obstacleSpacing: CGFloat = 800
    let cameraNode = SKCameraNode()
    
    func didBegin(_ contact: SKPhysicsContact) {
        if let nodeA = contact.bodyA.node as? SKShapeNode, let nodeB = contact.bodyB.node as? SKShapeNode{
            if nodeA.fillColor != nodeB.fillColor{
                player.physicsBody?.velocity.dy = 0
                player.removeFromParent()
                score = 0
                scoreLabel.text = String(score)
                addPlayer(colour: .blue)
            }
            if nodeA.fillColor == nodeB.fillColor{
                score += 1
                scoreLabel.text = String(score)
            }
        }
    }
    
    func addPlayer(colour: UIColor){
        player.fillColor = colour
        player.strokeColor = player.fillColor
        player.position = CGPoint(x: 0, y: 10)
        
        //Physics Properties
        let playerBody = SKPhysicsBody(circleOfRadius: 15)
        playerBody.mass = 1.5
        playerBody.categoryBitMask = PhysicsCategory.Player
        playerBody.collisionBitMask = 4
        player.physicsBody = playerBody
        
        //Add to scene
        addChild(player)
    }
    
    
    func addCircle(){
        let path = UIBezierPath()
        path.move(to: CGPoint(x: 0, y: -200))
        path.addLine(to: CGPoint(x:0, y: -160))
        path.addArc(withCenter: CGPoint.zero, radius:160, startAngle: CGFloat(3.0 * (Double.pi / 2)), endAngle: CGFloat(0), clockwise: true)
        path.addLine(to: CGPoint(x: 200, y: 0))
        path.addArc(withCenter: CGPoint.zero, radius: 200, startAngle: CGFloat(0.0), endAngle: CGFloat(3.0 * (Double.pi / 2)), clockwise: false)
        
        let obstacle = SKNode()
        
        for i in 0...3{
            let colours = [UIColor.yellow, UIColor.red, UIColor.blue, UIColor.purple]
            let section = SKShapeNode(path: path.cgPath)
            section.position = CGPoint(x: 0, y: 0)
            section.fillColor = colours[i]
            section.strokeColor = colours[i]
            section.zRotation = CGFloat(Double.pi / 2) * CGFloat(i);
            
            //Physics Properties
            let sectionBody = SKPhysicsBody(polygonFrom: path.cgPath)
            sectionBody.categoryBitMask = PhysicsCategory.Obstacles
            sectionBody.collisionBitMask = 0
            sectionBody.contactTestBitMask = PhysicsCategory.Player
            sectionBody.affectedByGravity = false
            section.physicsBody = sectionBody
            
            //Add to Obstacle
            obstacle.addChild(section)
        }
        obstacle.position = CGPoint(x: 0, y: 220)
        addChild(obstacle)
        
        let rotateAction = SKAction.rotate(byAngle: 2.0 * CGFloat(Double.pi), duration: 8.0)
        obstacle.run(SKAction.repeatForever(rotateAction))
    }
    
    func addSquare(){
        let path = UIBezierPath(roundedRect: CGRect(x: -200, y: -200, width: 400, height: 40), cornerRadius: 20)
        
        let obstacle = SKNode()
        
        for i in 0...3{
            let colours = [UIColor.yellow, UIColor.red, UIColor.blue, UIColor.purple]
            let section = SKShapeNode(path: path.cgPath)
            section.position = CGPoint(x: 0, y: 0)
            section.fillColor = colours[i]
            section.strokeColor = colours[i]
            section.zRotation = CGFloat(Double.pi / 2) * CGFloat(i);
            
            //Physics Properties
            let sectionBody = SKPhysicsBody(polygonFrom: path.cgPath)
            sectionBody.categoryBitMask = PhysicsCategory.Obstacles
            sectionBody.collisionBitMask = 0
            sectionBody.contactTestBitMask = PhysicsCategory.Player
            sectionBody.affectedByGravity = false
            section.physicsBody = sectionBody
            
            //Add to Obstacle
            obstacle.addChild(section)
        }
        
        obstacle.position = CGPoint(x: 0, y: 900)
        addChild(obstacle)
        
        let rotateAction = SKAction.rotate(byAngle: -2.0 * CGFloat(Double.pi), duration: 8.0)
        obstacle.run(SKAction.repeatForever(rotateAction))
    }
    
    let scoreLabel = SKLabelNode()
    var score = 0
    
    override func didMove(to view: SKView) {
        physicsWorld.contactDelegate = self
        physicsWorld.gravity.dy = -22
        
        addPlayer(colour: .blue)
        addCircle()
        addSquare()
        
        addChild(cameraNode)
        camera = cameraNode
        cameraNode.position = player.position
        
        scoreLabel.position = CGPoint(x: 180, y: 0)
        scoreLabel.fontColor = .white
        scoreLabel.fontSize = 100
        scoreLabel.text = String(score)
        cameraNode.addChild(scoreLabel)
    }
    
    override func update(_ currentTime: TimeInterval) {
        let playerPositionInCamera = cameraNode.convert(player.position, to: self)
        if playerPositionInCamera.y > 0 && !cameraNode.hasActions(){
            cameraNode.position.y = player.position.y
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        player.physicsBody?.velocity.dy = 600.0
    }
    
}

// Load the Scene
let scene = GameScene(size: CGSize(width: 480, height: 640))
scene.scaleMode = .aspectFill

let view = SKView(frame: CGRect(x:0, y:0, width: 480, height: 640))
view.presentScene(scene)
PlaygroundPage.current.liveView = view
//#-end-editable-code
