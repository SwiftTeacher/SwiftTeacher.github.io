//  AnswersLiveView.swift

import UIKit
import PlaygroundSupport

public func setupLiveView() {
    PlaygroundPage.current.liveView = {
        let answersViewController = AnswersViewController()
        return answersViewController
    }()
}

// MARK: LiveView Client

class AnswersLiveViewClient : PlaygroundRemoteLiveViewProxyDelegate  {
    init() {}
    
    func show(_ string: String) {
        guard Thread.isMainThread else {
            DispatchQueue.main.sync { [unowned self] in
                self.show(string)
            }
            return
        }

        guard let liveViewMessageHandler = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy else {
            return
        }

        liveViewMessageHandler.send(.string(string))

        let delay: TimeInterval = UIAccessibilityIsVoiceOverRunning() ? 4.0 : 1
        RunLoop.main.run(until: Date(timeIntervalSinceNow: delay))
    }
    
    func changeImage(_ image: UIImage) {
        guard let data = UIImagePNGRepresentation(image) else { return }
        
        guard let liveViewMessageHandler = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy else {
            return
        }
        
        liveViewMessageHandler.send(.data(data))
    }
    
    
    
    // MARK: PlaygroundRemoteLiveViewProxyDelegate Methods
    
    func remoteLiveViewProxyConnectionClosed(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy) {
    }
    
    func remoteLiveViewProxy(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy, received message: PlaygroundValue) {
    }
}
