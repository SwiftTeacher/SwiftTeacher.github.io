//#-editable-code
import PlaygroundSupport
import MapKit

let seminyak = CLLocationCoordinate2D(latitude: -8.693793, longitude: 115.162216)

// Now let's create a MKMapView
let mapView = MKMapView(frame: CGRect(x:0, y:0, width:800, height:800))

// Define a region for our map view
var mapRegion = MKCoordinateRegion()

let mapRegionSpan = 1.02
mapRegion.center = seminyak
mapRegion.span.latitudeDelta = mapRegionSpan
mapRegion.span.longitudeDelta = mapRegionSpan

mapView.setRegion(mapRegion, animated: true)

//added
mapView.mapType = .hybridFlyover
let camera = MKMapCamera(lookingAtCenter: seminyak, fromDistance: 550000, pitch: 30, heading: 262)
mapView.camera = camera


// Create a map annotation
let seminyakAnnotation = MKPointAnnotation()
seminyakAnnotation.coordinate = seminyak
seminyakAnnotation.title = "Seminyak, Bali"
mapView.addAnnotation(seminyakAnnotation)

let lombokAnnotation = MKPointAnnotation()
lombokAnnotation.coordinate = CLLocationCoordinate2D(latitude: -8.287, longitude: 116.452)
lombokAnnotation.title = "Epicenter"
lombokAnnotation.subtitle = "Depth: 25.6km, Magnitude: 6.9"

mapView.addAnnotation(lombokAnnotation)


// Add the created mapView to our Playground Live View
PlaygroundPage.current.liveView = mapView
//#-end-editable-code
