

public func shapes() {
    
    var label = Model.text("Geometry / 3D Shapes", elevation: 20.cm)
    scene.add(label)
    label.applyColor(scheme: .cool)
    
    var cube = Model.cube(size: 0.1)
    scene.add(cube)
    
    var cylinder = Model.cylinder(size: 0.1, height: 0.1)
    scene.add(cylinder)
    
    var sphere = Model.sphere(size: 0.1)
    scene.add(sphere)
    
    var pyramid = Model.pyramid(width: 0.1, height: 0.1, depth: 0.1)
    scene.add(pyramid)
    
    scene.camera.when(cube, isWithin: 20.cm, do: {
        cube.speak(text: "This is a cube. It has 6 faces. 12 edges. And 8 vertices.")
    
        scene.camera.when(cylinder, isWithin: 20.cm, do: {
            cylinder.speak(text: "Here is a cylinder. It has 1 curved face and 2 flat faces. It has 2 edges and no vertices. Can you think of everyday objects that are like a cylinder?")
        })
    
        scene.camera.when(sphere, isWithin: 20.cm, do: {
            sphere.speak(text: "Here's a sphere! It has one curved face. No edges and no vertices. It is a bit like a football. Or soccer ball if you live in the USA.")
        })

        scene.camera.when(pyramid, isWithin: 20.cm, do: {
            pyramid.speak(text: "This is a square based pyramid. It has 5 faces. 8 edges and 5 vertices.")
        })
})
}
