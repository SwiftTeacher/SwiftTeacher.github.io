
// 
//  LiveView.swift
//
//  Copyright © 2016-2018 Apple Inc. All rights reserved.
//

import PlaygroundSupport


let liveViewController = DynamicComposerViewController()

PlaygroundPage.current.liveView = liveViewController

